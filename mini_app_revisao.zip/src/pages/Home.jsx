import React from 'react'

export default function Home() {
  return <h1>Bem-vindo ao Mini App de Revisão!</h1>
}
